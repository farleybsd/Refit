# OnionArchitecture
Exemplo de Onion Architecture (Arquitetura Cebola)
